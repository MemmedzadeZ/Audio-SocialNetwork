﻿using Microsoft.AspNetCore.Identity;

namespace SocialNetworkProject_3_22_05.Entities
{
    public class CustomIdentityRole:IdentityRole
    {
    }
}
