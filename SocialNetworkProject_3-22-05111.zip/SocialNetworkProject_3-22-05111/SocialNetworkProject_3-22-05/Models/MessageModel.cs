﻿namespace SocialNetworkProject_3_22_05.Models
{
    public class MessageModel
    {
        public string? ReceiverId { get; set; }
        public string? SenderId { get; set; }
        public string? Content { get; set; }
    }
}
